## Design Notes:  DCAE on Kubernetes
### Background: Previous Support for DCAE on Docker
### Key Design Elements for DCAE on Kubernetes
#### Use of Kubernetes Abstractions
#### Networking
#### Service Discovery
#### Component Configuration
#### Health Checking and Resiliency
#### Scaling
#### Software Updates
### Changes to Cloudify Type Definitions
### Impact to Other DCAE Components
### Status of Work
